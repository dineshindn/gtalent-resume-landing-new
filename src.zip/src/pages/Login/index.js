import React, { Fragment } from "react";
import LoginForm from "../../component/views/Login";

const LoginMain = () => {
  return (
    <Fragment>
     <LoginForm />
    </Fragment>
  );
};
export default LoginMain;
